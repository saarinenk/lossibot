# lossibot
A telegram bot for finding the next departure(s) for Vartsalan lossi in Kustavi, Finland.
